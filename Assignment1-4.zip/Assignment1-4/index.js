function myFunction() {
    var hr=parseInt(document.getElementById("headsratio").value);
    var n=parseInt(document.getElementById("inputnumber").value);
    document.getElementById("output").innerHTML = headsRatio(n,hr);

}
function headsRatio(n,hr){
    return n/hr;
}